window.revelar =  ScrollReveal({reset:true})

// Topo do Site
revelar.reveal('.efeito-txt-topo',{
    duration: 3000, // milisegundos
    distance: '90px'
})

revelar.reveal('.efeito-img-topo',{
    duration: 3000, // milisegundos
    distance: '90px',
    delay: 900
})

// Vídeo Como Funciona
revelar.reveal('.comofunciona__video',{
    duration: 2000, // milisegundos
    distance: '90px',
})

// FAQ -  Section
revelar.reveal('.faq',{
    duration: 2000, // milisegundos
    distance: '90px',
})
