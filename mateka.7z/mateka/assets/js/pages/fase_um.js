// Ação botão de start
document.getElementById('botao-iniciar').addEventListener('click', comecarTutorial);

// Troca de telas até o início do jogo.
function comecarTutorial() {
    document.getElementById('tela-iniciar').classList.add('hidden');
    document.getElementById('tela-iniciar').classList.add('hidden');
    document.getElementById('tela-tutorial').classList.remove('hidden');
}

// Ação botão troca de slides no tutorial.
document.querySelectorAll('.tutorial-opcoes').forEach(button => {
    button.addEventListener('click', proximoSlide);
});


// Escondendo o Slide Atual e Mostrando o Próximo
let slideAtual = 0;
function proximoSlide(){
    slideAtual++;
    const slides = document.querySelectorAll('#tela-tutorial .slide');
    if(slideAtual < slides.length){
        slides[slideAtual - 1].classList.add('hidden');
        slides[slideAtual].classList.remove('hidden');
    }else{
        comecarJogo();
    }
}

let estrelas = 3;
let pontuacao = 0;

// Escondendo tela de tutorial e mostrando a do jogo.
function comecarJogo(){
    document.getElementById('tela-tutorial').classList.add('hidden');
    document.getElementById('tela-jogo').classList.remove('hidden');
    atualizarEstrelas();
    mostrarNumero();
}

// Número aleatório
function mostrarNumero(){
    const numeroAleatorio = Math.floor(Math.random() * 9) + 1;
    document.getElementById('mostrar-numero').innerText = numeroAleatorio;
    mostrarCestas(numeroAleatorio);
}

function mostrarCestas(numeroCerto){
    const cestas = document.getElementById('cestas');
    cestas.innerHTML = '';

    // Gerar três números incorretos.
    const numerosIncorretos = [];
    while (numerosIncorretos.length < 3){
        const num = Math.floor(Math.random() * 9) + 1;
        if(num !== numeroCerto && !numerosIncorretos.includes(num)){
            numerosIncorretos.push(num);
        }
    }

    // Combinar numeros corretos com incorretos e misturar
    const numeros = [numeroCerto, ...numerosIncorretos].sort(() => Math.random() - 0.5);

    // Criar div das cestas.
    numeros.forEach(numero => {
        const cesta = document.createElement('div');
        cesta.classList.add('cesta');
        cesta.innerHTML = `<img src="cesta${numero}.png" alt="Cesta with ${numero} fruits"><br>${numero}`;
        cesta.addEventListener('click', () => checarResposta(numeroCerto, numero));
        cestas.appendChild(cesta);
    });
}

function checarResposta(numeroCerto, numeroSelecionado){
    if (numeroCerto === numeroSelecionado){
        pontuacao++;
    } else{
        estrelas--;
    }

    atualizarEstrelas();

    if (pontuacao === 10 || estrelas === 0){
        acabarJogo();
    } else{
        mostrarNumero();
    }
}

function atualizarEstrelas(){
    const containerEstrelas = document.getElementById('estrelas');
    containerEstrelas.innerHTML = '';
    for (let i = 0; i < 3; i++){
        const estrela = document.createElement('span');
        estrela.classList.add('estrela');
        estrela.innerHTML = i < estrelas ? '★' : '☆';
        containerEstrelas.appendChild(estrela)
    }
};

function acabarJogo(){
    document.getElementById('tela-jogo').classList.add('hidden');
    document.getElementById('tela-resultado').classList.remove('hidden');
    const mensagemResultado = document.getElementById('mensagem-resultado');
    const textoEstrela = estrelas === 1 ? 'estrela' : 'estrelas';
    if(estrelas > 0){
        mensagemResultado.innerHTML = `Parabéns!<br>Você terminou com ${estrelas} ${textoEstrela}!`;
    } else{
        mensagemResultado.innerHTML = 'Que pena! <br> Você perdeu todas as estrelas. <br> Tente novamente.';
    }
};

// Arrumar dps
document.getElementById('botao-restart').addEventListener('click', () => {
    document.getElementById('tela-resultado').classList.add('hidden');
    document.getElementById('tela-jogo').classList.remove('hidden');
    estrelas = 3;
    pontuacao = 0;
});

document.getElementById('botao-voltar').addEventListener('click', () =>{
    document.getElementById('tela-resultado').classList.add('hidden');
    document.getElementById('tela-jogo').classList.add('hidden');
    document.getElementById('tela-iniciar').classList.remove('hidden');
    estrelas = 3;
    pontuacao = 0;
});


