let erros = 4;
let fases = 0;
let acertos = 8;

function Trocar() {
    let iniciar = document.querySelector('.iniciar')
    if(iniciar) {
        removeIniciar()
    }

    limpaNumsEOp()

    let randomNum = Math.floor(Math.random() * 9) + 1;

    adicionarNumero(randomNum);

    adicionarOpcoes(randomNum);

}


function embaralharArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]]; // Troca os elementos de posição
    }
    return array;
}


function nova() {
    setTimeout(Trocar, 1000)
}


function verificarResposta(opcao, resposta) {
    if(erros <= 5) {
        fases++
        nova();
    }
    else {
        derrota()
    }
    return opcao == resposta;
}


function adicionarNumero(numero) {
    let container = document.querySelector('.container');
    if (container) {
        let imagem = document.createElement("img");
        imagem.src = "assets/image/numero" + numero + ".jpg";
        imagem.alt = "Número: " + numero;
        imagem.className = "num numero" + numero;
        container.insertBefore(imagem, container.firstChild);
    } else {
        console.error("O contêiner para os números não foi encontrado.");
    }
}


function derrota() {
    let container = document.querySelector(".container")
    container.style.display = "none"
    let h1 = document.createElement("h1")
    h1.textContent = "Voce Perdeu!"
    if (document.body.firstChild) {
        document.body.insertBefore(h1, document.body.firstChild);
    } else {
        document.body.appendChild(h1);
    }
}


function removeIniciar() {
    let iniciar = document.querySelector(".iniciar") 
    iniciar.remove()

    let container = document.querySelector(".container")

    let h1 = document.createElement('h1')
    h1.textContent = "Qual a quantidade de frutas representa este numero?"
    container.insertBefore(h1, container.firstChild)

    let explicacao = document.querySelector('.container p')
    explicacao.remove()
}


function verificarVitoria() {
    if(acertos == 10) {
        let container = document.querySelector(".container")
        container.style.display = "none"
        let h1 = document.createElement("h1")
        h1.textContent = "Voce Ganhou!"
        if (document.body.firstChild) {
            document.body.insertBefore(h1, document.body.firstChild);
        } else {
            document.body.appendChild(h1);
        }
        let divOptions = document.createElement("div")
        divOptions.className = "divOptions"
        document.body.appendChild(divOptions)


        let backLink = document.createElement("a")
        backLink.href = "#"
        backLink.textContent = "Voltar"
        divOptions.appendChild(backLink)

        let againLink = document.createElement("a")
        againLink.textContent = "Tentar Novamente"
        againLink.href = "#"
        againLink.onclick = function(event) {
            event.preventDefault(); // Impede o comportamento padrão do link
            window.location.reload(); // Recarrega a página
        };        
        divOptions.appendChild(againLink)

        let nextLink = document.createElement("a")
        nextLink.href = "#"
        nextLink.textContent = "Proxima Fase"
        divOptions.appendChild(nextLink)


    }
} 


function limpaNumsEOp() {
    let opcoes = document.querySelectorAll('.op');
    opcoes.forEach(opcao => {
        opcao.remove();
    });

    let numeroUsados = document.querySelectorAll('.num');
    numeroUsados.forEach(numero => {
        numero.remove();
    });
}


function adicionarOpcoes(numero) {
    let opcoesNumeros = new Set();
    opcoesNumeros.add(numero);
    while (opcoesNumeros.size < 4) {
        opcoesNumeros.add(Math.floor(Math.random() * 9) + 1);
    }
    
    let opcoesArray = Array.from(opcoesNumeros);
    opcoesArray = embaralharArray(opcoesArray)
    let containerOptions = document.querySelector('.containerOptions');
    for (let i = 0; i < opcoesArray.length; i++) {
        let o = document.createElement("img");
        let src = "assets/image/" + opcoesArray[i] + ".jpg";
        o.src = src;
        o.alt = "Número: " + opcoesArray[i];
        o.className = "op option" + opcoesArray[i];
        o.onclick = function() {
            if(verificarResposta(opcoesArray[i], numero)) {
                o.className = "op option" + opcoesArray[i] + " certa"
                acertos++
                verificarVitoria()
            }
            else {
                o.className = "op option" + opcoesArray[i] + " errada"
                erros++
            }
        };
        containerOptions.appendChild(o);
    }
}
