document.getElementById('cpf').addEventListener('input', function (e) {
    let cpf = e.target.value.replace(/\D/g, '');
    if (cpf.length > 3 && cpf.length < 7) {
        cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    } else if (cpf.length > 6 && cpf.length < 10) {
        cpf = cpf.replace(/(\d{3})(\d{3})(\d)/, '$1.$2.$3');
    } else if (cpf.length > 9 && cpf.length < 12) {
        cpf = cpf.replace(/(\d{3})(\d{3})(\d{3})(\d)/, '$1.$2.$3-$4');
    }
    e.target.value = cpf;
});

function validarSenha() {
    let senha = document.getElementById("senha").value;
    let confirmarsenha = document.getElementById("confirmarsenha").value;
    let campoSenha = document.getElementById("senha");
    let campoConfirmarSenha = document.getElementById("confirmarsenha");

    // Verifica se as senhas correspondem
    if (senha !== confirmarsenha) {
        campoConfirmarSenha.setCustomValidity("As senhas não correspondem!");
    } else {
        campoConfirmarSenha.setCustomValidity("");
    }

    // Verifica se a senha atende aos requisitos de segurança
    if (!temLetraMinuscula(senha) || !temLetraMaiuscula(senha) || !temNumero(senha) || senha.length < 8) {
        campoSenha.setCustomValidity(
            "Requisitos da senha: \n" +
            "- Ter no mínimo 8 caracteres \n"+
            "- 1 letra minúscula \n"+
            "- 1 letra maiúscula \n"+
            "- 1 número \n"
        );
    } else {
        campoSenha.setCustomValidity("");
    }

    // Se as senhas não forem válidas, não permitir o envio do formulário
    return campoConfirmarSenha.validity.valid && campoSenha.validity.valid;
}

function temLetraMinuscula(senha) {
    return /[a-z]/.test(senha);
}

function temLetraMaiuscula(senha) {
    return /[A-Z]/.test(senha);
}

function temNumero(senha) {
    return /\d/.test(senha);
}

