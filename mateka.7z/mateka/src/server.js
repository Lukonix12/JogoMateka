const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
const crypto = require('crypto');

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser,json());

admin.initializeApp({
    credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    }),
});

const db = admin.firestore();

async function sendConfirmationEmail(email) {
    const transporter = nodemailer.createTransport({
        service:'gmail',
        auth: {
            user:process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS,
        },
    });

    const mailOptins = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: 'Confirmação de Cadastro',
        text: 'Seu cadastro foi realizado com sucesso. \n\n\n\n\n\n Seja bem vindo a família MATEKA! \n\n\n\n\n Esperamos que tenha uma boa jornada, e lembre-se estamos aqui para qualquer coisa.'
    };

    await transporter.sendMail(mailOptins);
        
}

function validarCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');

    if (cpf.length !== 11) return false;

    if (/^(\d)\1{10}$/.test(cpf)) return false;

    let soma = 0;
    let resto;

    for (let i = 1; i <= 9; i++) {
        soma += parseInt(cpf.charAt(i - 1)) * (11 - i);
    }
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.charAt(9))) return false;

    soma = 0;

    for (let i = 1; i <= 10; i++) {
        soma += parseInt(cpf.charAt(i - 1)) * (12 - i);
    }
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.charAt(10))) return false;

    return true;
};

func

app.post('/api/registerResponsavel', async(req, res) => {
    
    const { nome, cpf, email, senha} = req.body;

    if(validarCPF(cpf)) {
        return res.status(400).send('CPF inválido');
    }
    
    const bcrypt = require('bcrypt');
    const hashedPassword = await bcrypt.hash(senha, 10);


    try {
        await db.collection('responsaveis').add({
            nome,
            cpf,
            email,
            senha: hashedPassword,
        });

        await sendConfirmationEmail(email);
        res.status(201).send('Cadastro realizado com sucesso!');
    } catch(error) {
        res.status(500).send('Erro ao realizar cadastro'+ error.message);
    }
    
});

const PORT = process.env.PORT || 3000; 
app.listen(PORT, () => {
    console.log('Servidor rodando na porta ${PORT}')
}) 